import { test, expect } from '@playwright/test';

test.beforeEach(async({page})=>{await page.goto('/');await page.evaluate(()=>document.fonts.ready);});

test('the selected person and parents show complete dates, places and occupations',async({page})=>{
  await expect(page.locator('.focus-card')).toContainText('12 במאי 1985');
  await expect(page.locator('.focus-card')).toContainText('18 בספטמבר 2009');
  await expect(page.locator('.focus-card')).toContainText('אדריכלית');
  const father=page.locator('.parent-card').filter({hasText:'דוד לוין'});
  await expect(father).toContainText('8 במרץ 1954');
  await expect(father).toContainText('חיפה, ישראל');
  await expect(father).toContainText('מהנדס בניין');
  await expect(page.locator('.relative-trigger[aria-expanded=false]')).toHaveCount(3);
});

test('grandparents stay compact and are navigable when another generation is opened',async({page})=>{
  await page.getByRole('button',{name:/עוד דור/}).click();
  await expect(page.locator('.fx-grandparents .fx-person-chip')).toHaveCount(4);
  await page.locator('.fx-grandparents').getByRole('button',{name:'מעבר אל יוסף לוין',exact:true}).click();
  await expect(page.locator('.focus-card h2')).toHaveText('יוסף לוין');
  await expect(page.locator('.focus-card')).toContainText('6 בינואר 2002');
  await expect(page.locator('.focus-card')).toContainText('78 שנים');
});

test('profile tabs show a complete timeline, source citations and the original record',async({page})=>{
  await page.getByRole('tab',{name:'ציר זמן',exact:true}).click();
  const timeline=page.getByRole('tabpanel',{name:'ציר זמן',exact:true});
  await expect(timeline).toBeVisible();
  await expect(timeline).toContainText('18 בספטמבר 2009');
  await expect(timeline).toContainText('עם איתי כהן');
  await page.getByRole('tab',{name:/מקורות/}).click();
  const sources=page.locator('#person-panel-sources');
  await expect(sources.locator('.fx-source-card')).toHaveCount(3);
  await expect(sources).toContainText('אלבום משפחת לוין');
  await expect(sources).toContainText('מקור בדוי');
  await sources.locator('summary').click();
  await expect(sources.locator('pre')).toContainText('1 NAME תמר /לוין/');
  await page.getByRole('tab',{name:'פרטים',exact:true}).click();
  await page.getByRole('button',{name:'לקריאת הסיפור המלא',exact:true}).click();
  await expect(page.locator('#person-panel-overview')).toContainText('בכל יום שישי');
});

test('rolled-up relative nodes can be selected without opening full cards',async({page})=>{
  await page.getByRole('button',{name:'מעבר אל נועה כהן',exact:true}).click();
  await expect(page.locator('.focus-card h2')).toHaveText('נועה כהן');
  await expect(page.locator('.parent-card')).toHaveText([/איתי כהן/,/תמר לוין/]);
});

test('branch counts open a list of actual descendants and navigate to them',async({page})=>{
  await expect(page.locator('.fx-branch-stats')).toContainText('10');
  await page.locator('.fx-branch-stats').getByRole('button',{name:/3.*צאצאים/}).click();
  await expect(page.locator('.fx-branch-people>button')).toHaveCount(3);
  await page.locator('.fx-branch-people').getByRole('button').filter({hasText:'מאיה כהן'}).click();
  await expect(page.locator('.focus-card h2')).toHaveText('מאיה כהן');
});

test('all expanded information remains within narrow portrait layouts',async({page})=>{
  await page.getByRole('button',{name:/עוד דור/}).click();
  for(const button of await page.locator('.relative-trigger').all())await button.click();
  for(const width of [320,360,390,430,768,1024,1440]){
    await page.setViewportSize({width,height:900});
    expect(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth),`width ${width}`).toBe(true);
  }
});


test('profile tabs support RTL arrow keys, Home and End',async({page})=>{
  const overview=page.getByRole('tab',{name:'פרטים',exact:true});
  await overview.focus();await page.keyboard.press('ArrowLeft');
  await expect(page.getByRole('tab',{name:'ציר זמן',exact:true})).toHaveAttribute('aria-selected','true');
  await page.keyboard.press('End');
  await expect(page.getByRole('tab',{name:/מקורות/})).toHaveAttribute('aria-selected','true');
  await page.keyboard.press('Home');
  await expect(overview).toHaveAttribute('aria-selected','true');
});
