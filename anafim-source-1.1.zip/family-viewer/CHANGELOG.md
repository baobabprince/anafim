# Changelog

## 1.1.0 — 2026-10-18

### Fixed: valid user files failed in protected viewers

The embedded demo used the synchronous GEDCOM parser, while every file upload depended on starting an external/module Web Worker. If a sandbox or CSP blocked that worker, the upload showed a generic file-reading error even though the GEDCOM was valid. There was no direct-import fallback, and transferring the only input ArrayBuffer would also prevent a retry after a worker error.

The failure was reproduced with the previous standalone HTML in an iframe with `sandbox="allow-scripts"` and `worker-src 'none'`.

- Added a shared, independently tested file-import pipeline.
- Automatically falls back to direct, local parsing if the Worker API is unavailable, construction fails, a worker script is blocked, postMessage fails, the worker crashes or its startup/progress watchdog expires.
- Keeps the original bytes available for retries; no longer transfers the only ArrayBuffer.
- Uses a cooperative asynchronous wrapper around the same parser for direct loading, yielding between chunks and supporting cancellation.
- Supports FileReader when File.arrayBuffer is unavailable or fails.
- Added specific user-facing import error codes, and correct messages for PDF, ZIP, empty and unreadable files.
- Allows content-valid GEDCOM files with non-standard filename extensions when selected by the file provider or dropped into the dialog.
- Shows viewer version and successful import method under file details.
- Added byte-for-byte, public third-party fixtures covering UTF-8, UTF-16 LE/BE, ANSEL, Family Tree Maker, Legacy and Family Historian sample exports.
- Added production-HTML browser tests inside a protected, offline iframe with workers explicitly blocked, plus unavailable/crashed/unresponsive-worker regression tests.

All genealogy data continues to be processed locally. The tests do not require or include any user's private family data.
